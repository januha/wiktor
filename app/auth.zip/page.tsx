import '/app/css/main.css';
export default function Home() {
  return (
    <main>
      <div className="greeting-box">
        <div className='greeting-box-name'>
          <h1><p>&gt; Witaj.</p></h1>
        
        </div>
        <hr />
        <div className="greeting-box-content">
          <p>&gt; Witaj na mojej stronie.</p>
        </div>
      </div>
    </main>
  );
}
