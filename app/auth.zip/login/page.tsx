import '../css/login.css';
import { auth, signIn, signOut } from "@/app/auth"
import Image from 'next/image';

export default async function Login() {
    const session = await auth();
    console.log(session);
    const user = session?.user
    
  return user ?
  
  ( 
    <div className="login-box">
      <div className='login-box-name'>
        <h1>&gt; Witaj {user.name}
        </h1>
      </div>
      <hr />
      <div className="login-box-content">
      <form
        action={async () => {
              "use server"
              await signOut();
        }}
      >
      <button className="sign-Out" style={{ 
              backgroundColor: "transparent",
              backgroundRepeat: "no-repeat",
              border: "none",
              cursor: "pointer",
              overflow: "hidden",
              outline: "none",
              color: "rgb(107, 192, 193)",
              fontSize: "17px"
              }}>
              Wyloguj się
              
            </button>
      </form></div>
    </div>
    )
  :
  (
    <main>
  <div className="login-box">
    <div className="login-box-name">
      <h1>&gt; Logowanie.</h1>
    </div>
    <hr />
    <div className="login-box-content">
        <span className="google">
          <form action={async () => { 
              "use server";
              await signIn("google");
          }}>
              <div style={{
                float: "left"
              }}>
              &gt; Nie masz konta?&nbsp;
              
              <button type="submit" style={{ 
              backgroundColor: "transparent",
              backgroundRepeat: "no-repeat",
              border: "none",
              cursor: "pointer",
              overflow: "hidden",
              outline: "none",
              color: "rgb(107, 192, 193)",
              fontSize: "17px"
              }}>
              Zarejestruj się
              
            </button>
            </div>
          </form>
        </span>
    </div>
  </div>
</main>

  )
}