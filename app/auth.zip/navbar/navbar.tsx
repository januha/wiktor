import Image from "next/image";
import bgImage from '/app/images/test1.png'

const Navbar = () => {
    return (
        <>
          <nav>
            <Image
              className='bg-Image'
              src={bgImage.src}
              alt="bgImage"
              width={1000}
              height={1000}
            />
              <div className="navbar">
                <img src="favicon.ico" alt="ikona" />
                <p className="project-Name">Projekt Strony</p>
                <div className="items">
                  <p className="main-Page">
                    <a href="/">Strona główna</a>
                  </p>
                  <p className="login">
                    <a href="/login">Logowanie</a>
                  </p>
                  <p className="about">
                    <a href="/about">O nas</a>
                  </p>
                </div>
              </div>
            </nav>
          </>
          
    );
  };
export default Navbar;