import React from "react";

export default function About() {
  return (
    <div>
      <a href="..">O nas</a>
    </div>
  );
}
